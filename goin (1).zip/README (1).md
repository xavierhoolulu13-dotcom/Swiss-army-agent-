# Node + React + Supabase Starter

Minimal starter combining:
- Frontend: React (Vite) + @supabase/supabase-js for auth and client operations
- Backend: Node.js (Express) acting as a protected API that verifies Supabase user tokens and uses the Supabase service role key for server-side DB writes
- Database/Auth: Supabase (Postgres + Auth + Storage optional)

Features
- Sign up / sign in with Supabase (email/password)
- Client lists user's bookmarks by calling the protected backend
- Client can add bookmarks via the backend (server writes using service role key)

Security notes
- The backend verifies the client's access token by calling Supabase's auth endpoint.
- The backend uses the service role key (keep this secret, do not commit) to perform server-side DB operations.
- For production, use HTTPS, store secrets in a secret manager, and consider additional rate-limiting and validation.

Get started
1. Create a Supabase project: https://app.supabase.com
2. Note your SUPABASE_URL and create an API key:
   - Use the anon/public key for client-side usage (VITE_SUPABASE_ANON_KEY).
   - Create/copy the service_role key for server-side usage (SUPABASE_SERVICE_KEY). Keep it secret.
3. Run the SQL migration to create the bookmarks table:
   - Use `psql` or Supabase SQL editor and run `server/create_table.sql`.
4. Create environment files:
   - server/.env (see server/.env.example)
   - client/.env (see client/.env example below)
5. Install & run:
   - In `server/`: npm install && npm run dev
   - In `client/`: npm install && npm run dev
6. Open the frontend URL printed by Vite (usually http://localhost:5173).

What’s included (high level)
- server/
  - index.js — Express API with /api/bookmarks (GET, POST)
  - .env.example — required env vars
  - create_table.sql — SQL to create bookmarks table
- client/
  - Vite + React app
  - src/Auth and src/Bookmarks components

If you want, I can:
- Convert backend to TypeScript
- Add server-side validation and rate-limiting
- Add deployment instructions (Vercel/Render/Heroku and Supabase)
- Add tests or GitHub Actions CI
