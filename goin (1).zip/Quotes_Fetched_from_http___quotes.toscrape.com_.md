# Quotes Fetched from http://quotes.toscrape.com/

| Quote | Author |
| :--- | :--- |
| “The world as we have created it is a process of our thinking. It cannot be changed without changing our thinking.” | Albert Einstein |
| “It is our choices, Harry, that show what we truly are, far more than our abilities.” | J.K. Rowling |
| “There are only two ways to live your life. One is as though nothing is a miracle. The other is as though everything is a miracle.” | Albert Einstein |
| “The person, be it gentleman or lady, who has not pleasure in a good novel, must be intolerably stupid.” | Jane Austen |
| “Imperfection is beauty, madness is genius and it's better to be absolutely ridiculous than absolutely boring.” | Marilyn Monroe |
| “Try not to become a man of success. Rather become a man of value.” | Albert Einstein |
| “It is better to be hated for what you are than to be loved for what you are not.” | André Gide |
| “I have not failed. I've just found 10,000 ways that won't work.” | Thomas A. Edison |
| “A woman is like a tea bag; you never know how strong it is until it's in hot water.” | Eleanor Roosevelt |
| “A day without sunshine is like, you know, night.” | Steve Martin |
