#!bin/bash
java -jar agent.jar
